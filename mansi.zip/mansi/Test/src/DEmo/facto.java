package DEmo;

public class facto 
{
	
	public static void main(String[] args)
	{

		int i,r=1;
		int num=3;

		for(i=1;i<=num;i++)
		{
			r=r*i;
			
		}
		System.out.println("Factorial is "+r);
	}

}
