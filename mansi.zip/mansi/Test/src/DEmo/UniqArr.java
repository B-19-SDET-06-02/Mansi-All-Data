package DEmo;

public class UniqArr
{
	int[] arr= {6,5,4,6,5,3,2};
	public void dup()
	{
	
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UniqArr oo=new UniqArr();
oo.dup();
	}

}
