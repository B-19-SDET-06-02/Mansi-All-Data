package StaticDemo;

public class StaticMethod {
	static int num1, num2,res;
	public static void add()
	{
		res=num1+num2;
	System.out.println(res);	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
add();
	}

}
