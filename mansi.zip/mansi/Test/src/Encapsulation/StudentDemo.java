package Encapsulation;

public class StudentDemo {

	private int rollno;
	private String Name;
	private int MArks;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getMArks() {
		return MArks;
	}
	public void setMArks(int mArks) {
		MArks = mArks;
	}
}
