package Encapsulation;

public class EncapDemo {
	
	public void acc()
	{
		StudentDemo oo=new StudentDemo();
		oo.setRollno(1);
		System.out.println(oo.getRollno());
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
EncapDemo ob=new EncapDemo();
ob.acc();
	}

}
