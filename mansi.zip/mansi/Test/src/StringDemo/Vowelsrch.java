package StringDemo;

public class Vowelsrch {
String str="Mansi";

public void vow()
{
	System.out.println(str);
	
if(str.contains("a"))
{
System.out.println("The string contains a vowel");
}
else if(str.contains("e"))
	
{
	System.out.println("The string contains a vowel");
	}
else if(str.contains("i"))
	
{
	System.out.println("The string contains a vowel");
	}
else if(str.contains("o"))
	
{
	System.out.println("The string contains a vowel");
	}

else if(str.contains("u"))
	
{
	System.out.println("The string contains a vowel");
	}

}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Vowelsrch oo=new Vowelsrch();
oo.vow();
	}

}
