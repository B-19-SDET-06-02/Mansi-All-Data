package StringDemo;

public class ContainDemo 
{
String str="mansi batra";
String st[];
public void acc()
{
//if(str.contains("ma"))
//		{
//	System.out.println("Contains ma");
//
//		}
//else
//{
//System.out.println("Does not contain");	
//}
	
//	System.out.println("-----------");
//	str=str.replace("mansi", "mano");
//	System.out.println("Replaced string is :"+str);
	
	
//System.out.println("SPlitting string");
//st=str.split(" ");
//System.out.println(st[1]);
	
//	System.out.println("-----To Upper case----");
//	str=str.toUpperCase();
//			System.out.println(str);
	
	
System.out.println("Substring is :");
	str=str.substring(4,8);
	System.out.println(str);
			
			
			
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ContainDemo oo= new ContainDemo();
oo.acc();
	}

}
