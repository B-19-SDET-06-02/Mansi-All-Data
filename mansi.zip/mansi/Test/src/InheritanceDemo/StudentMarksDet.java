package InheritanceDemo;

public class StudentMarksDet extends StudentDemo {
int hindi,eng,maths;
public void accept()
{
System.out.println("Enter marks for Maths");
maths=sc.nextInt();
System.out.println("Enter marks for English");
eng=sc.nextInt();

}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
