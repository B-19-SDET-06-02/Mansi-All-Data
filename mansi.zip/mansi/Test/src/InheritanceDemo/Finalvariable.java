package InheritanceDemo;

public class Finalvariable {
final double pie=3.146;
public void acc()
{
//pie++;
System.out.println(pie);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Finalvariable oo=new Finalvariable();
oo.acc();
	}

}
