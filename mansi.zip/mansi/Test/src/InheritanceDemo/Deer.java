package InheritanceDemo;

public class Deer extends AnimalDemo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Deer oo= new Deer();
oo.Eat();
oo.drink();
	}
	void Eat()
{
System.out.println("Deer is vegetarian");	
}
	}


