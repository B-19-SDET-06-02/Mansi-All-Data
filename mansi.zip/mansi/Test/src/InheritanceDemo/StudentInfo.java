package InheritanceDemo;

public class StudentInfo implements StudenttInterface {

	int regid;
	String name;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void perdet()
	{
		System.out.println("Personal details");
	}
	public void qual_det()
	{
		System.out.println("Personal details");
		
	}

}
