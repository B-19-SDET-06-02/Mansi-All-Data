package InheritanceDemo;

abstract class AnimalDemo {
abstract void Eat();//abstract method
void drink()//concrete method
{
System.out.println("All animals drink water");
}

}
