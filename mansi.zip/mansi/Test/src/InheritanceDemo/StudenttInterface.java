package InheritanceDemo;

interface StudenttInterface {
int a=10;
	
	void perdet();

	void qual_det();

}
