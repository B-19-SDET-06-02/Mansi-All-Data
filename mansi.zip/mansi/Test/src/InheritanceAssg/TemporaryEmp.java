package InheritanceAssg;

public class TemporaryEmp extends Assignment{

	void calculate_balance_leaves()
	{
		
	}
	boolean avail_leave(int no_of_leaves, char type_of_leave)
	{

	}
	void calculate_salary()
	{
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
