package InheritanceAssg;

public class PermanentEmp extends Assignment{
	int paid_leave, sick_leave, casual_leave;
	double basic, hra,pfa;
	
	void print_leave_details()
	{
		System.out.println("The leave details are :-");
		
	}
	void calculate_balance_leaves()
	{
		
	}
	boolean avail_leave(boolean no_of_leaves, boolean type_of_leave)
	{
		return no_of_leaves;
	}
	void calculate_salary()
	{
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
